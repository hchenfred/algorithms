# How to run this program

## run "npm install xml2js" in terminal
## the starting point is index.js file, go to the folder and run "node index.js"
## the genertated files are stored in output folder
## if you need to test a different file, please change the file name inside index.js
